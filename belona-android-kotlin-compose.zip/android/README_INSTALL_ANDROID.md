# BELONA — Native Android App (Kotlin + Jetpack Compose)

This `/android` folder contains the complete, standalone **Native Android Application** for **BELONA** (`com.amaai.belona`) built with **Kotlin** and **Jetpack Compose (Material 3)**.

When installed on your physical Android phone, **BELONA**:
- Has its own **BELONA** Royal Blue **"B"** adaptive icon on your phone's home screen and app drawer (`@mipmap/ic_launcher`).
- Opens directly as a **100% standalone native Android application** (`MainActivity`), **never** inside Chrome.
- Preserves all BELONA features:
  1. **2-Second Launch Splash Screen**: `"BELONA"` centered with `"from AMA AI"` at the bottom.
  2. **Phone (`+234`) & 13+ Date of Birth Login** + Google Sign-In + Banned Phone Check.
  3. **WhatsApp / Telegram-Style Chats & Groups**: Text messages, Voice Notes (`0:24`), Photo sharing, unread badges, contact search, and Data Saver mode.
  4. **24-Hour Disappearing Status Updates**: Create and view 24-hour status stories with emerald unviewed rings.
  5. **Belona Full-Screen Vertical Video Feed (`VerticalPager`)**: `Contacts | Friends | For You | LIVE`, Likes, Comments, Favourites, and Sponsored MTN 5G Commercials.
  6. **AI Safety Auto-Moderation & Community Reporting**: Immediate auto-deletion of prohibited content + 1 strike (auto-ban at 5 strikes), 20+ rapid video report deletion, and 30% viewer report auto-ban (`User Not Found`).
  7. **Live Streaming & 50/50 Gift Split**: Paystack Naira Coin top-up and 50% Host Diamonds / 50% Platform settlement.
  8. **18+ KYC Blue Tick Verification & Creator Wallet**: `Starter Verified (10+)` & `Creator Verified (1,000+)` tiers + Naira bank withdrawal (minimum ₦5,000).

---

## How to Install the Native BELONA Android App on Your Physical Android Phone

### Method 1: Install Directly via Android Studio (Recommended — USB or Wireless Debugging)

1. **Download the BELONA Android Project**:
   - Click **"Download Native Android Project (.zip)"** inside the BELONA app (or download `/belona-android-kotlin-compose.zip`), and unzip the `android/` folder on your computer.
2. **Open in Android Studio**:
   - Open **Android Studio** (Ladybug / Koala or newer).
   - Click **Open** and select the **`android`** folder.
   - Wait for Gradle Sync to finish automatically.
3. **Enable Developer Options & USB / Wireless Debugging on Your Android Phone**:
   - On your physical Android phone, open **Settings → About phone**.
   - Tap **Build number** 7 times until you see *"You are now a developer!"*.
   - Go back to **Settings → System → Developer options**.
   - Turn ON **USB debugging** (if using a USB cable) **OR** turn ON **Wireless debugging** (to pair over Wi-Fi without a cable).
4. **Connect & Run**:
   - Connect your phone via USB cable (and tap **Allow USB debugging** on your phone screen) or pair via **Pair device using Wi-Fi QR code** in Android Studio.
   - Select your phone in the top device dropdown in Android Studio and click the green **Run ▶ (`Shift + F10`)** button.
   - **BELONA** will compile and install directly onto your phone with its own **Blue B** home screen icon!

---

### Method 2: Build the Installable `BELONA.apk` File & Install Directly on Your Phone

1. **Build the APK**:
   - In Android Studio, click **Build → Build Bundle(s) / APK(s) → Build APK(s)** (or run `./gradlew assembleDebug` in the terminal inside `/android`).
2. **Locate the APK**:
   - Your installable APK file is generated at:
     `android/app/build/outputs/apk/debug/app-debug.apk`
3. **Transfer & Install on Your Phone**:
   - Send `app-debug.apk` to your Android phone (via WhatsApp, Telegram, Google Drive, or USB cable).
   - Tap the `.apk` file on your phone.
   - If prompted, allow **"Install unknown apps"** for your file manager, then tap **Install**.
   - Tap **Open** — **BELONA** launches as a standalone native Android app!
