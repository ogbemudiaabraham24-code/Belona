package com.amaai.belona.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.amaai.belona.model.*
import java.time.LocalDate
import java.time.Period

class BelonaViewModel : ViewModel() {

    var showSplash by mutableStateOf(true)
        private set

    var currentUser by mutableStateOf<UserProfile?>(null)
        private set

    var activeSurface by mutableStateOf(BelonaSurface.CHATS)
        private set

    var showLiveModal by mutableStateOf(false)
        private set

    var bannedReason by mutableStateOf("")
        private set

    var isBannedLocked by mutableStateOf(false)
        private set

    var users by mutableStateOf(InitialBelonaData.INITIAL_USERS)
        private set

    var chats by mutableStateOf(InitialBelonaData.INITIAL_CHATS)
        private set

    var statuses by mutableStateOf(InitialBelonaData.INITIAL_STATUSES)
        private set

    var videos by mutableStateOf(InitialBelonaData.INITIAL_VIDEOS)
        private set

    var inboxItems by mutableStateOf(InitialBelonaData.INITIAL_INBOX)
        private set

    var withdrawals by mutableStateOf<List<WithdrawalRecord>>(emptyList())
        private set

    var bannedRecords by mutableStateOf(InitialBelonaData.INITIAL_BANNED_RECORDS)
        private set

    private val bannedPhones = mutableListOf("+2348099990000", "+2348122223333")

    fun completeSplash() {
        showSplash = false
    }

    fun navigateToSurface(surface: BelonaSurface) {
        activeSurface = surface
    }

    fun openLiveStream(open: Boolean) {
        showLiveModal = open
    }

    fun calculateAge(dob: String): Int {
        return try {
            val parts = dob.split("-").map { it.toInt() }
            if (parts.size != 3) return 20
            val birthDate = LocalDate.of(parts[0], parts[1], parts[2])
            Period.between(birthDate, LocalDate.now()).years
        } catch (_: Exception) {
            20
        }
    }

    fun loginWithPhoneAndDob(
        username: String,
        phone: String,
        dob: String
    ): Pair<Boolean, String?> {
        val normalizedPhone = if (phone.startsWith("+")) phone.trim() else "+234${phone.trim().removePrefix("0")}"
        if (bannedPhones.contains(normalizedPhone)) {
            isBannedLocked = true
            bannedReason = "Your phone number ($normalizedPhone) is permanently banned on BELONA."
            return Pair(false, bannedReason)
        }

        val age = calculateAge(dob)
        if (age < 13) {
            return Pair(false, "You must be at least 13 years old to use BELONA.")
        }

        val cleanHandle = "@" + username.lowercase().replace(" ", "_").ifEmpty { "belona_creator" }
        val user = UserProfile(
            id = "usr-me",
            username = username.ifBlank { "Belona Creator" },
            handle = cleanHandle,
            phone = normalizedPhone,
            dob = dob,
            bio = "Official BELONA Android Creator · Lagos, NG",
            verifiedStatus = false,
            followersCount = 15,
            followingCount = 42,
            likesCount = 320,
            videosCount = 22,
            accountAgeDays = 14,
            coins = 2500,
            diamonds = 7500,
            relation = "self"
        )
        currentUser = user
        activeSurface = BelonaSurface.CHATS
        return Pair(true, null)
    }

    fun resetBannedDemoAccount() {
        isBannedLocked = false
        bannedReason = ""
        currentUser = null
    }

    fun sendChatMessage(chatId: String, text: String, type: MessageType = MessageType.TEXT, voiceDuration: String? = null) {
        val user = currentUser ?: return
        if (text.isBlank() && type == MessageType.TEXT) return

        val newMsg = ChatMessage(
            id = "m-${System.currentTimeMillis()}",
            senderId = user.id,
            senderName = user.username,
            type = type,
            text = text,
            voiceDuration = voiceDuration,
            timestamp = "Just now"
        )

        chats = chats.map { thread ->
            if (thread.id == chatId) {
                val preview = when (type) {
                    MessageType.VOICE -> "Voice note (${voiceDuration ?: "0:12"})"
                    MessageType.IMAGE -> "📷 Photo: $text"
                    MessageType.VIDEO -> "🎬 Video: $text"
                    MessageType.TEXT -> text
                }
                thread.copy(
                    lastMessage = preview,
                    lastTimestamp = "Just now",
                    unreadCount = 0,
                    messages = thread.messages + newMsg
                )
            } else {
                thread
            }
        }
    }

    fun createNewChatOrGroup(name: String, phone: String, isGroup: Boolean) {
        if (name.isBlank()) return
        val newChat = ChatThread(
            id = "chat-${System.currentTimeMillis()}",
            participantId = "usr-${System.currentTimeMillis()}",
            participantName = name.trim(),
            participantPhone = phone.ifBlank { "+2348000000000" },
            participantVerified = false,
            isGroup = isGroup,
            groupMembersCount = if (isGroup) 5 else 0,
            unreadCount = 0,
            lastMessage = if (isGroup) "Group created on BELONA" else "Tap to start chatting",
            lastTimestamp = "Just now",
            messages = emptyList()
        )
        chats = listOf(newChat) + chats
    }

    fun addStatusUpdate(caption: String) {
        val user = currentUser ?: return
        if (caption.isBlank()) return
        val status = StatusUpdate(
            id = "st-${System.currentTimeMillis()}",
            userId = user.id,
            userName = user.username,
            userVerified = user.verifiedStatus,
            caption = caption.trim(),
            createdAt = "Just now",
            expiresInHours = 24,
            viewed = false
        )
        statuses = listOf(status) + statuses
    }

    fun markStatusViewed(statusId: String) {
        statuses = statuses.map {
            if (it.id == statusId) it.copy(viewed = true) else it
        }
    }

    fun toggleDataSaver() {
        val user = currentUser ?: return
        currentUser = user.copy(dataSaver = !user.dataSaver)
    }

    fun toggleBusinessAccount() {
        val user = currentUser ?: return
        currentUser = user.copy(isBusiness = !user.isBusiness)
    }

    fun toggleLikeVideo(videoId: String) {
        videos = videos.map { v ->
            if (v.id == videoId) {
                val nextLiked = !v.likedByMe
                v.copy(
                    likedByMe = nextLiked,
                    likes = if (nextLiked) v.likes + 1 else (v.likes - 1).coerceAtLeast(0)
                )
            } else v
        }
    }

    fun toggleFavouriteVideo(videoId: String) {
        videos = videos.map { v ->
            if (v.id == videoId) {
                val nextFav = !v.favouritedByMe
                v.copy(
                    favouritedByMe = nextFav,
                    favourites = if (nextFav) v.favourites + 1 else (v.favourites - 1).coerceAtLeast(0)
                )
            } else v
        }
    }

    fun addVideoComment(videoId: String, text: String) {
        val user = currentUser ?: return
        if (text.isBlank()) return
        val comment = VideoComment(
            id = "c-${System.currentTimeMillis()}",
            userId = user.id,
            username = user.username,
            text = text.trim(),
            createdAt = "Just now",
            verified = user.verifiedStatus
        )
        videos = videos.map { v ->
            if (v.id == videoId) v.copy(comments = v.comments + comment) else v
        }
    }

    /**
     * AI Safety Auto-Moderation:
     * Auto-deletes prohibited videos immediately, adds +1 strike, and bans user at 5 strikes.
     */
    fun postVideoWithSafetyModeration(caption: String, mediaTag: String): Pair<Boolean, String> {
        val user = currentUser ?: return Pair(false, "Not signed in")
        val combinedUpper = "$caption $mediaTag".uppercase()
        val matched = InitialBelonaData.FORBIDDEN_TERMS.filter { combinedUpper.contains(it) }

        if (matched.isNotEmpty()) {
            val nextStrikes = user.strikesCount + 1
            val nowBanned = nextStrikes >= 5
            val warningMsg =
                "STOP POSTING INVALID VIDEOS HERE. Flagged: ${matched.joinToString()}. Strike $nextStrikes/5."

            currentUser = user.copy(strikesCount = nextStrikes, banned = nowBanned)
            inboxItems = listOf(
                BelonaInboxItem(
                    id = "inb-${System.currentTimeMillis()}",
                    type = "safety",
                    title = "Auto-Deleted Invalid Video (Strike $nextStrikes/5)",
                    detail = warningMsg,
                    timestamp = "Just now"
                )
            ) + inboxItems

            if (nowBanned) {
                bannedPhones.add(user.phone)
                isBannedLocked = true
                bannedReason = "Reached 5/5 strikes for posting prohibited content."
            }
            return Pair(false, warningMsg)
        }

        val newVideo = VideoPost(
            id = "vid-${System.currentTimeMillis()}",
            authorId = user.id,
            authorName = user.username,
            authorHandle = user.handle,
            authorVerified = user.verifiedStatus,
            category = "foryou",
            caption = caption.ifBlank { "New clip on BELONA Android! #Belona" },
            musicTrack = "Original Sound — ${user.username}",
            themeColorHex = 0xFF1D4ED8,
            likes = 1,
            likedByMe = true,
            favourites = 0,
            shares = 0,
            views = 100
        )
        videos = listOf(newVideo) + videos
        currentUser = user.copy(videosCount = user.videosCount + 1)
        return Pair(true, "Video published to BELONA feed!")
    }

    /**
     * Community Reporting Engine:
     * - 20+ Rapid Video Reports -> Auto-deletes video & adds 1 strike
     * - >=30% Viewer Report Ratio -> Auto-bans creator & masks profile as "User Not Found"
     */
    fun reportVideoOrCreator(
        video: VideoPost,
        reason: ReportReason,
        mode: String // "single" | "rapid_20_video" | "viewer_30_percent"
    ): String {
        val addedReports = when (mode) {
            "rapid_20_video" -> 20
            "viewer_30_percent" -> 35
            else -> 1
        }
        val updatedVideoReports = video.reportsCount + addedReports
        val videoDeleted = updatedVideoReports >= 20
        val bannedByReports = mode == "viewer_30_percent"

        if (videoDeleted || bannedByReports) {
            videos = videos.filterNot { it.id == video.id }
        } else {
            videos = videos.map {
                if (it.id == video.id) it.copy(reportsCount = updatedVideoReports) else it
            }
        }

        if (bannedByReports) {
            bannedRecords = listOf(
                BannedUserRecord(
                    id = "ban-${System.currentTimeMillis()}",
                    userId = video.authorId,
                    phone = "+2348091112233",
                    username = video.authorHandle,
                    reason = "Community Report 30% Rule (${reason.label})",
                    banType = "COMMUNITY_REPORTS_30_PERCENT",
                    strikesCount = 2,
                    reportRatioPercent = 34.0
                )
            ) + bannedRecords
        }

        return when {
            bannedByReports -> "${video.authorName} exceeded 30% viewer reports and was auto-banned (User Not Found)."
            videoDeleted -> "Video received 20+ rapid reports and was auto-deleted (+1 strike)."
            else -> "Report submitted (${reason.label}). Thank you for keeping BELONA safe."
        }
    }

    fun buyCoinsPaystack(coinsAmount: Int) {
        val user = currentUser ?: return
        currentUser = user.copy(coins = user.coins + coinsAmount)
    }

    fun sendLiveGift(gift: GiftItem): Boolean {
        val user = currentUser ?: return false
        if (user.coins < gift.coins) return false
        val hostDiamonds = gift.coins / 2 // 50/50 split
        currentUser = user.copy(
            coins = (user.coins - gift.coins).coerceAtLeast(0),
            diamonds = user.diamonds + hostDiamonds
        )
        return true
    }

    fun boostFollowersForLive() {
        val user = currentUser ?: return
        currentUser = user.copy(followersCount = (user.followersCount + 10).coerceAtLeast(15))
    }

    fun applyForBlueTickVerification(kyc: KycSubmission): Pair<Boolean, String> {
        val user = currentUser ?: return Pair(false, "Not signed in")
        val age = calculateAge(user.dob)
        if (age < 18) {
            return Pair(false, "Must be 18+ to get verified on BELONA.")
        }
        val minFollowers = kyc.tier.minFollowers
        if (user.followersCount < minFollowers) {
            return Pair(false, "Requires at least $minFollowers followers for ${kyc.tier.label}.")
        }
        currentUser = user.copy(
            verificationPending = true,
            verifiedTier = kyc.tier,
            kycData = kyc
        )
        inboxItems = listOf(
            BelonaInboxItem(
                id = "inb-${System.currentTimeMillis()}",
                type = "verification",
                title = "18+ KYC (${kyc.tier.label}) Sent to Admin",
                detail = "Legal Name: ${kyc.fullLegalName} · ID: ${kyc.ninOrIdNumber}. Open Admin to approve your Blue Tick!",
                timestamp = "Just now"
            )
        ) + inboxItems
        return Pair(true, "KYC submitted! Approve your Blue Tick in Admin Dashboard.")
    }

    fun adminApproveBlueTick(approve: Boolean) {
        val user = currentUser ?: return
        currentUser = user.copy(
            verifiedStatus = approve,
            verificationPending = false
        )
    }

    fun withdrawCreatorDiamonds(amountNaira: Int, bankName: String, accountNumber: String): Pair<Boolean, String> {
        val user = currentUser ?: return Pair(false, "Not signed in")
        if (amountNaira < 5000) {
            return Pair(false, "Minimum withdrawal is ₦5,000.")
        }
        if (amountNaira > user.diamonds) {
            return Pair(false, "Insufficient Diamonds balance.")
        }
        val record = WithdrawalRecord(
            id = "wd-${System.currentTimeMillis()}",
            amountNaira = amountNaira,
            diamondsRedeemed = amountNaira,
            bankName = bankName.ifBlank { "Access Bank" },
            accountNumber = accountNumber.ifBlank { "0123456789" }
        )
        withdrawals = listOf(record) + withdrawals
        currentUser = user.copy(
            diamonds = user.diamonds - amountNaira,
            withdrawnNaira = user.withdrawnNaira + amountNaira
        )
        return Pair(true, "₦$amountNaira withdrawn to $bankName ($accountNumber)!")
    }
}
