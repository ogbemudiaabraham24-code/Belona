package com.amaai.belona.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amaai.belona.model.*
import com.amaai.belona.ui.theme.*

@Composable
fun BelonaFeedScreen(
    currentUser: UserProfile,
    videos: List<VideoPost>,
    inboxItems: List<BelonaInboxItem>,
    withdrawals: List<WithdrawalRecord>,
    onExitToChats: () -> Unit,
    onOpenLive: () -> Unit,
    onOpenAdmin: () -> Unit,
    onToggleLike: (videoId: String) -> Unit,
    onToggleFavourite: (videoId: String) -> Unit,
    onAddComment: (videoId: String, text: String) -> Unit,
    onPostVideoAttempt: (caption: String, mediaTag: String) -> Pair<Boolean, String>,
    onReportVideoOrUser: (video: VideoPost, reason: ReportReason, mode: String) -> String,
    onApplyKyc: (kyc: KycSubmission) -> Pair<Boolean, String>,
    onWithdrawEarnings: (amountNaira: Int, bankName: String, accountNumber: String) -> Pair<Boolean, String>,
    onToggleDataSaver: () -> Unit,
    onToggleBusiness: () -> Unit
) {
    var bottomTab by remember { mutableStateOf("belona") } // belona | friends | post | inbox | me
    var feedCategory by remember { mutableStateOf("foryou") } // contacts | friends | foryou
    var activeCommentVideo by remember { mutableStateOf<VideoPost?>(null) }
    var activeReportVideo by remember { mutableStateOf<VideoPost?>(null) }
    var feedbackBanner by remember { mutableStateOf<String?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color.Black,
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = bottomTab == "belona",
                    onClick = { bottomTab = "belona" },
                    icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Belona") },
                    label = { Text("Belona", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
                NavigationBarItem(
                    selected = bottomTab == "friends",
                    onClick = {
                        bottomTab = "belona"
                        feedCategory = "friends"
                    },
                    icon = { Icon(Icons.Default.Group, contentDescription = "Friends") },
                    label = { Text("Friends", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = bottomTab == "post",
                    onClick = { bottomTab = "post" },
                    icon = {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(BelonaRoyalBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Post", tint = Color.White)
                        }
                    },
                    label = { Text("Post", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
                NavigationBarItem(
                    selected = bottomTab == "inbox",
                    onClick = { bottomTab = "inbox" },
                    icon = { Icon(Icons.Default.Notifications, contentDescription = "Inbox") },
                    label = { Text("Inbox (${inboxItems.size})", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = bottomTab == "me",
                    onClick = { bottomTab = "me" },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Me") },
                    label = { Text("Me", fontSize = 10.sp) }
                )
            }
        },
        containerColor = Color.Black
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (bottomTab) {
                "post" -> {
                    PostVideoSurface(
                        strikesCount = currentUser.strikesCount,
                        onPost = { caption, tag ->
                            val (ok, msg) = onPostVideoAttempt(caption, tag)
                            feedbackBanner = msg
                            if (ok) bottomTab = "belona"
                        }
                    )
                }
                "inbox" -> {
                    InboxSurface(inboxItems = inboxItems)
                }
                "me" -> {
                    MeProfileAndWalletSurface(
                        currentUser = currentUser,
                        withdrawals = withdrawals,
                        onApplyKyc = {
                            val (_, msg) = onApplyKyc(it)
                            feedbackBanner = msg
                        },
                        onWithdraw = { amt, bank, acct ->
                            val (_, msg) = onWithdrawEarnings(amt, bank, acct)
                            feedbackBanner = msg
                        },
                        onToggleDataSaver = onToggleDataSaver,
                        onToggleBusiness = onToggleBusiness,
                        onOpenAdmin = onOpenAdmin,
                        onExitToChats = onExitToChats
                    )
                }
                else -> {
                    val filteredVideos = if (feedCategory == "foryou") {
                        videos
                    } else {
                        videos.filter { it.category == feedCategory }.ifEmpty { videos }
                    }

                    val pagerState = rememberPagerState(pageCount = { filteredVideos.size })

                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize()
                    ) { page ->
                        val video = filteredVideos[page]
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(video.themeColorHex),
                                            BelonaDeepNavy,
                                            Color.Black
                                        )
                                    )
                                )
                        ) {
                            // Center Video Visual Indicator
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                BelonaLogoBadge(size = 68.dp, fontSizeSp = 32)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (video.isSponsoredAd) "SPONSORED COMMERCIAL" else "BELONA VERTICAL VIDEO",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                            }

                            // Bottom-Left Creator Info & Caption
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(start = 16.dp, end = 88.dp, bottom = 24.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (video.isSponsoredAd) {
                                    Surface(
                                        color = BelonaAmber,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "SPONSORED · ${video.sponsorBrand ?: "Partner"}",
                                            color = Color.Black,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = video.authorHandle,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    if (video.authorVerified) {
                                        VerifiedBlueTick()
                                    }
                                }
                                Text(
                                    text = video.caption,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "🎵 ${video.musicTrack}",
                                    color = BelonaSkyBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Right-Side Vertical Action Rail
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(end = 14.dp, bottom = 24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(18.dp)
                            ) {
                                // Like Button
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { onToggleLike(video.id) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = "Like",
                                        tint = if (video.likedByMe) BelonaRose else Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Text("${video.likes}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                // Comment Button
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { activeCommentVideo = video }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChatBubble,
                                        contentDescription = "Comments",
                                        tint = Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                    Text("${video.comments.size}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                // Favourite Button
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { onToggleFavourite(video.id) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = "Favourite",
                                        tint = if (video.favouritedByMe) BelonaAmber else Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                    Text("${video.favourites}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                // Safety Report Button
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { activeReportVideo = video }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Flag,
                                        contentDescription = "Report",
                                        tint = Color(0xFFF87171),
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Text("Report", color = Color(0xFFFCA5A5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Top Navigation Overlay: Back to Chats | Contacts | Friends | For You | LIVE
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = onExitToChats) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Chats", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("contacts" to "Contacts", "friends" to "Friends", "foryou" to "For You").forEach { (key, label) ->
                                Text(
                                    text = label,
                                    color = if (feedCategory == key) Color.White else Color.Gray,
                                    fontWeight = if (feedCategory == key) FontWeight.Black else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    modifier = Modifier.clickable { feedCategory = key }
                                )
                            }
                        }

                        Button(
                            onClick = onOpenLive,
                            colors = ButtonDefaults.buttonColors(containerColor = BelonaRose),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("LIVE", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            if (feedbackBanner != null) {
                Surface(
                    color = BelonaRoyalBlue,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 58.dp, start = 16.dp, end = 16.dp)
                        .clickable { feedbackBanner = null }
                ) {
                    Text(
                        text = feedbackBanner ?: "",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }

    if (activeCommentVideo != null) {
        val v = activeCommentVideo!!
        var commentText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { activeCommentVideo = null },
            title = { Text("Comments (${v.comments.size})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    v.comments.forEach { c ->
                        Text("${c.username}: ${c.text}", fontSize = 13.sp)
                    }
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        label = { Text("Add comment...") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddComment(v.id, commentText)
                        activeCommentVideo = null
                    }
                ) {
                    Text("Post")
                }
            },
            dismissButton = {
                TextButton(onClick = { activeCommentVideo = null }) {
                    Text("Close")
                }
            }
        )
    }

    if (activeReportVideo != null) {
        val v = activeReportVideo!!
        AlertDialog(
            onDismissRequest = { activeReportVideo = null },
            title = { Text("Community Safety Report") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportReason.entries.forEach { reason ->
                        OutlinedButton(
                            onClick = {
                                feedbackBanner = onReportVideoOrUser(v, reason, "single")
                                activeReportVideo = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Report: ${reason.label}")
                        }
                    }
                    Button(
                        onClick = {
                            feedbackBanner = onReportVideoOrUser(v, ReportReason.VIOLENCE, "rapid_20_video")
                            activeReportVideo = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BelonaAmber),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate 20+ Rapid Video Reports (Auto-Delete)", color = Color.Black, fontSize = 11.sp)
                    }
                    Button(
                        onClick = {
                            feedbackBanner = onReportVideoOrUser(v, ReportReason.SCAM, "viewer_30_percent")
                            activeReportVideo = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BelonaRose),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate 30% Viewer Reports (Auto-Ban User)", fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeReportVideo = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PostVideoSurface(
    strikesCount: Int,
    onPost: (caption: String, mediaTag: String) -> Unit
) {
    var caption by remember { mutableStateOf("") }
    var mediaTag by remember { mutableStateOf("CLEAN_DANCE_CLIP") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Post to BELONA Feed (AI Safety Shield Active)",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "Current Safety Strikes: $strikesCount / 5 (Auto-ban at 5 strikes)",
            color = BelonaSkyBlue,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("Video Caption & Hashtags") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { onPost(caption, mediaTag) },
            colors = ButtonDefaults.buttonColors(containerColor = BelonaRoyalBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Publish Safe Video")
        }
        Button(
            onClick = { onPost("Invalid test video with GUNS and NUDITY", "PROHIBITED_CONTENT") },
            colors = ButtonDefaults.buttonColors(containerColor = BelonaRose),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Test AI Auto-Delete + Add 1 Strike")
        }
    }
}

@Composable
private fun InboxSurface(inboxItems: List<BelonaInboxItem>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "BELONA Activity & Safety Inbox",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )
        }
        items(inboxItems, key = { it.id }) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(item.detail, color = Color.LightGray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(item.timestamp, color = BelonaSkyBlue, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun MeProfileAndWalletSurface(
    currentUser: UserProfile,
    withdrawals: List<WithdrawalRecord>,
    onApplyKyc: (KycSubmission) -> Unit,
    onWithdraw: (Int, String, String) -> Unit,
    onToggleDataSaver: () -> Unit,
    onToggleBusiness: () -> Unit,
    onOpenAdmin: () -> Unit,
    onExitToChats: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BelonaLogoBadge(size = 48.dp, fontSizeSp = 22)
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(currentUser.username, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                                if (currentUser.verifiedStatus) VerifiedBlueTick()
                            }
                            Text("${currentUser.handle} · ${currentUser.phone}", color = BelonaSkyBlue, fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = "Followers: ${currentUser.followersCount} · Videos: ${currentUser.videosCount} · Strikes: ${currentUser.strikesCount}/5",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Coins: ${currentUser.coins} · Host Diamonds: ₦${currentUser.diamonds}",
                        color = BelonaEmerald,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    onApplyKyc(
                        KycSubmission(
                            fullLegalName = currentUser.username,
                            ninOrIdNumber = "NIN-83920194821",
                            idPhotoName = "national_id_front.jpg",
                            selfieWithIdName = "selfie_with_id.jpg",
                            address = "Victoria Island, Lagos",
                            confirmed18Plus = true,
                            tier = VerificationTier.STARTER
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = BelonaRoyalBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Apply for 18+ KYC Blue Tick Verification")
            }
        }

        item {
            Button(
                onClick = { onWithdraw(5000, "Access Bank", "0123456789") },
                colors = ButtonDefaults.buttonColors(containerColor = BelonaEmerald),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Withdraw ₦5,000 Creator Diamonds to Bank")
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onToggleDataSaver, modifier = Modifier.weight(1f)) {
                    Text(if (currentUser.dataSaver) "Data Saver: ON" else "Data Saver: OFF", fontSize = 11.sp)
                }
                OutlinedButton(onClick = onToggleBusiness, modifier = Modifier.weight(1f)) {
                    Text(if (currentUser.isBusiness) "Business: ON" else "Business: OFF", fontSize = 11.sp)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenAdmin, modifier = Modifier.weight(1f)) {
                    Text("Open /admin")
                }
                OutlinedButton(onClick = onExitToChats, modifier = Modifier.weight(1f)) {
                    Text("Back to Chats")
                }
            }
        }
    }
}

@Composable
fun LiveStreamModalDialog(
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onBuyCoins: (Int) -> Unit,
    onSendGift: (GiftItem) -> Boolean,
    onBoostFollowers: () -> Unit
) {
    var statusNote by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("BELONA Live Stream (50/50 Gift Split)", fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Coins: ${currentUser.coins} · Host Diamonds: ₦${currentUser.diamonds}",
                    color = BelonaEmerald,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                if (currentUser.followersCount < 5) {
                    Text("Requires 5+ followers to host Live.", color = BelonaRose, fontSize = 12.sp)
                    Button(onClick = onBoostFollowers) {
                        Text("Boost to 15 Followers")
                    }
                }
                statusNote?.let {
                    Text(it, color = BelonaSkyBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = {
                        onBuyCoins(5000)
                        statusNote = "Added +5,000 Coins via Paystack!"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BelonaRoyalBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Top Up +5,000 Coins (Paystack ₦5,000)")
                }
                InitialBelonaData.GIFT_CATALOG.take(3).forEach { gift ->
                    OutlinedButton(
                        onClick = {
                            val sent = onSendGift(gift)
                            statusNote = if (sent) {
                                "Sent ${gift.emoji} ${gift.name}! 50% (${gift.coins / 2} Diamonds) credited to Host."
                            } else {
                                "Not enough coins for ${gift.name}. Top up first!"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Send ${gift.emoji} ${gift.name} (${gift.coins} Coins)")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Live")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    bannedRecords: List<BannedUserRecord>,
    currentUser: UserProfile?,
    onApproveBlueTick: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BelonaSlate900),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                title = {
                    Text("BELONA Admin & Safety Control", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            )
        },
        containerColor = BelonaDeepNavy
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("18+ KYC Blue Tick Verification Queue", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Applicant: ${currentUser?.username ?: "Amina Bello"} · 18+ NIN Verified",
                            color = BelonaSkyBlue,
                            fontSize = 12.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onApproveBlueTick(true) },
                                colors = ButtonDefaults.buttonColors(containerColor = BelonaEmerald)
                            ) {
                                Text("Approve Blue Tick")
                            }
                            OutlinedButton(onClick = { onApproveBlueTick(false) }) {
                                Text("Revoke")
                            }
                        }
                    }
                }
            }

            item {
                Text("Auto-Banned Accounts (5 Strikes & 30% Report Rule)", color = Color.White, fontWeight = FontWeight.Bold)
            }

            items(bannedRecords, key = { it.id }) { rec ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("${rec.username} (${rec.phone})", color = Color(0xFFF87171), fontWeight = FontWeight.Bold)
                        Text(rec.reason, color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
