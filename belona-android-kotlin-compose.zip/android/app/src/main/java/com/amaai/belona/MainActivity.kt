package com.amaai.belona

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.amaai.belona.model.BelonaSurface
import com.amaai.belona.ui.screens.*
import com.amaai.belona.ui.theme.BelonaTheme
import com.amaai.belona.viewmodel.BelonaViewModel

/**
 * Standalone Native Android Entry Point for BELONA (from AMA AI).
 * Opens directly from the Android home screen icon as a native app (not inside Chrome).
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BelonaTheme(darkTheme = true) {
                BelonaApp()
            }
        }
    }
}

@Composable
fun BelonaApp(belonaViewModel: BelonaViewModel = viewModel()) {
    // 1. 2-Second "BELONA from AMA AI" Splash Screen
    if (belonaViewModel.showSplash) {
        SplashScreen(onSplashFinished = { belonaViewModel.completeSplash() })
        return
    }

    // 2. Banned Lock Screen (5/5 Strikes or Banned Phone)
    if (belonaViewModel.isBannedLocked || belonaViewModel.currentUser?.banned == true) {
        BannedLockScreen(
            reason = belonaViewModel.bannedReason,
            strikesCount = belonaViewModel.currentUser?.strikesCount ?: 5,
            onResetDemoAccount = { belonaViewModel.resetBannedDemoAccount() }
        )
        return
    }

    // 3. Admin Dashboard Surface
    if (belonaViewModel.activeSurface == BelonaSurface.ADMIN) {
        AdminDashboardScreen(
            bannedRecords = belonaViewModel.bannedRecords,
            currentUser = belonaViewModel.currentUser,
            onApproveBlueTick = { belonaViewModel.adminApproveBlueTick(it) },
            onBack = { belonaViewModel.navigateToSurface(BelonaSurface.CHATS) }
        )
        return
    }

    // 4. Phone (+234) & 13+ Date of Birth Login Screen
    val user = belonaViewModel.currentUser
    if (user == null) {
        LoginScreen(
            onLogin = { username, phone, dob ->
                belonaViewModel.loginWithPhoneAndDob(username, phone, dob)
            }
        )
        return
    }

    // 5. Full-Screen Vertical Belona Video Feed Surface
    if (belonaViewModel.activeSurface == BelonaSurface.BELONA) {
        BelonaFeedScreen(
            currentUser = user,
            videos = belonaViewModel.videos,
            inboxItems = belonaViewModel.inboxItems,
            withdrawals = belonaViewModel.withdrawals,
            onExitToChats = { belonaViewModel.navigateToSurface(BelonaSurface.CHATS) },
            onOpenLive = { belonaViewModel.openLiveStream(true) },
            onOpenAdmin = { belonaViewModel.navigateToSurface(BelonaSurface.ADMIN) },
            onToggleLike = { belonaViewModel.toggleLikeVideo(it) },
            onToggleFavourite = { belonaViewModel.toggleFavouriteVideo(it) },
            onAddComment = { vid, txt -> belonaViewModel.addVideoComment(vid, txt) },
            onPostVideoAttempt = { cap, tag -> belonaViewModel.postVideoWithSafetyModeration(cap, tag) },
            onReportVideoOrUser = { vid, reason, mode -> belonaViewModel.reportVideoOrCreator(vid, reason, mode) },
            onApplyKyc = { belonaViewModel.applyForBlueTickVerification(it) },
            onWithdrawEarnings = { amt, bank, acct -> belonaViewModel.withdrawCreatorDiamonds(amt, bank, acct) },
            onToggleDataSaver = { belonaViewModel.toggleDataSaver() },
            onToggleBusiness = { belonaViewModel.toggleBusinessAccount() }
        )

        if (belonaViewModel.showLiveModal) {
            LiveStreamModalDialog(
                currentUser = user,
                onDismiss = { belonaViewModel.openLiveStream(false) },
                onBuyCoins = { belonaViewModel.buyCoinsPaystack(it) },
                onSendGift = { belonaViewModel.sendLiveGift(it) },
                onBoostFollowers = { belonaViewModel.boostFollowersForLive() }
            )
        }
        return
    }

    // 6. Default WhatsApp/Telegram-Style Chats & 24-Hour Status Updates Surface
    ChatsAndUpdatesScreen(
        activeSurface = belonaViewModel.activeSurface,
        currentUser = user,
        chats = belonaViewModel.chats,
        statuses = belonaViewModel.statuses,
        onChangeSurface = { belonaViewModel.navigateToSurface(it) },
        onSendMessage = { chatId, text, type, duration ->
            belonaViewModel.sendChatMessage(chatId, text, type, duration)
        },
        onCreateChatOrGroup = { name, phone, isGroup ->
            belonaViewModel.createNewChatOrGroup(name, phone, isGroup)
        },
        onAddStatus = { belonaViewModel.addStatusUpdate(it) },
        onMarkStatusViewed = { belonaViewModel.markStatusViewed(it) },
        onToggleDataSaver = { belonaViewModel.toggleDataSaver() }
    )
}
