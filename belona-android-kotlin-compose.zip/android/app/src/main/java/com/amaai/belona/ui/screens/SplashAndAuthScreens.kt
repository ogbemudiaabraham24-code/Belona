package com.amaai.belona.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amaai.belona.ui.theme.BelonaDeepNavy
import com.amaai.belona.ui.theme.BelonaRoyalBlue
import com.amaai.belona.ui.theme.BelonaSkyBlue
import com.amaai.belona.ui.theme.BelonaSlate900
import kotlinx.coroutines.delay

@Composable
fun BelonaLogoBadge(size: Dp = 44.dp, fontSizeSp: Int = 22) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3.2f))
            .background(BelonaRoyalBlue)
            .border(1.5.dp, BelonaSkyBlue.copy(alpha = 0.6f), RoundedCornerShape(size / 3.2f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "B",
            color = Color.White,
            fontSize = fontSizeSp.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
fun VerifiedBlueTick(modifier: Modifier = Modifier) {
    Icon(
        imageVector = Icons.Default.CheckCircle,
        contentDescription = "BELONA Verified Blue Tick",
        tint = BelonaSkyBlue,
        modifier = modifier.size(16.dp)
    )
}

@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(2000)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF172554), BelonaDeepNavy, Color.Black)
                )
            )
            .padding(28.dp)
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BelonaLogoBadge(size = 84.dp, fontSizeSp = 44)
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "BELONA",
                color = Color.White,
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "CHATS · 24H UPDATES · SHORT VIDEOS · LIVE",
                color = BelonaSkyBlue.copy(alpha = 0.85f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "from",
                color = Color.LightGray.copy(alpha = 0.7f),
                fontSize = 12.sp
            )
            Text(
                text = "AMA AI",
                color = BelonaSkyBlue,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
fun LoginScreen(
    onLogin: (username: String, phone: String, dob: String) -> Pair<Boolean, String?>
) {
    var username by remember { mutableStateOf("Abraham Ogbemudia") }
    var phone by remember { mutableStateOf("+2348031234567") }
    var dob by remember { mutableStateOf("2000-06-15") }
    var otpCode by remember { mutableStateOf("482910") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF172554), BelonaDeepNavy, Color.Black)
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BelonaSlate900)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BelonaLogoBadge(size = 48.dp, fontSizeSp = 24)
                    Column {
                        Text(
                            text = "BELONA",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Standalone Native Android App · from AMA AI",
                            color = BelonaSkyBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (errorMsg != null) {
                    Surface(
                        color = Color(0xFF7F1D1D),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMsg ?: "",
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number (+234)") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = dob,
                    onValueChange = { dob = it },
                    label = { Text("Date of Birth (YYYY-MM-DD · 13+ Required)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = otpCode,
                    onValueChange = { otpCode = it },
                    label = { Text("6-Digit SMS Verification Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val (ok, err) = onLogin(username, phone, dob)
                        if (!ok) errorMsg = err
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BelonaRoyalBlue)
                ) {
                    Text(
                        text = "Continue to BELONA Chats",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }

                OutlinedButton(
                    onClick = {
                        val (ok, err) = onLogin(username, phone, dob)
                        if (!ok) errorMsg = err
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "Continue with Google (+Phone & DOB)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Test Under-13 Block",
                        color = BelonaSkyBlue,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable {
                            dob = "2018-05-01"
                            val (_, err) = onLogin(username, phone, "2018-05-01")
                            errorMsg = err
                        }
                    )
                    Text(
                        text = "Test Banned Phone",
                        color = Color(0xFFF87171),
                        fontSize = 11.sp,
                        modifier = Modifier.clickable {
                            phone = "+2348099990000"
                            onLogin(username, "+2348099990000", dob)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun BannedLockScreen(
    reason: String,
    strikesCount: Int,
    onResetDemoAccount: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B2E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDC2626).copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Banned",
                        tint = Color(0xFFF87171),
                        modifier = Modifier.size(32.dp)
                    )
                }
                Text(
                    text = "Account Permanently Banned",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Your account has been banned for posting invalid content ($strikesCount/5 strikes). You have no access.",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
                if (reason.isNotBlank()) {
                    Text(
                        text = reason,
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Button(
                    onClick = onResetDemoAccount,
                    colors = ButtonDefaults.buttonColors(containerColor = BelonaRoyalBlue),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reset Demo Account")
                }
            }
        }
    }
}
