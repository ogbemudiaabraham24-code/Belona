package com.amaai.belona.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BelonaRoyalBlue = Color(0xFF1D4ED8)
val BelonaElectricBlue = Color(0xFF2563EB)
val BelonaSkyBlue = Color(0xFF38BDF8)
val BelonaDeepNavy = Color(0xFF020617)
val BelonaSlate900 = Color(0xFF0F172A)
val BelonaSlate800 = Color(0xFF1E293B)
val BelonaEmerald = Color(0xFF10B981)
val BelonaAmber = Color(0xFFF59E0B)
val BelonaRose = Color(0xFFF43F5E)

private val BelonaDarkColorScheme = darkColorScheme(
    primary = BelonaRoyalBlue,
    secondary = BelonaSkyBlue,
    tertiary = BelonaEmerald,
    background = BelonaDeepNavy,
    surface = BelonaSlate900,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val BelonaLightColorScheme = lightColorScheme(
    primary = BelonaRoyalBlue,
    secondary = BelonaElectricBlue,
    tertiary = BelonaEmerald,
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = BelonaSlate900,
    onSurface = BelonaSlate900
)

@Composable
fun BelonaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) BelonaDarkColorScheme else BelonaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
