package com.amaai.belona.model

enum class ReportReason(val label: String) {
    NUDITY("Nudity"),
    VIOLENCE("Violence/Gun/Killing"),
    SCAM("Scam"),
    HARASSMENT("Harassment"),
    DANGEROUS_ACT("Dangerous Act")
}

enum class VerificationTier(val label: String, val minFollowers: Int) {
    STARTER("Starter Verified (10+)", 10),
    CREATOR("Creator Verified (1,000+)", 1000)
}

enum class MessageType {
    TEXT, IMAGE, VIDEO, VOICE
}

enum class BelonaSurface {
    CHATS, UPDATES, BELONA, ADMIN
}

data class KycSubmission(
    val fullLegalName: String,
    val ninOrIdNumber: String,
    val idPhotoName: String,
    val selfieWithIdName: String,
    val address: String,
    val confirmed18Plus: Boolean,
    val tier: VerificationTier
)

data class WithdrawalRecord(
    val id: String,
    val amountNaira: Int,
    val diamondsRedeemed: Int,
    val bankName: String,
    val accountNumber: String,
    val status: String = "COMPLETED",
    val createdAt: String = "Just now"
)

data class UserProfile(
    val id: String,
    val username: String,
    val handle: String,
    val phone: String,
    val dob: String, // YYYY-MM-DD
    val avatarColorHex: Long = 0xFF1D4ED8,
    val bio: String,
    val verifiedStatus: Boolean = false,
    val verifiedTier: VerificationTier? = null,
    val verificationPending: Boolean = false,
    val kycData: KycSubmission? = null,
    val followersCount: Int = 12,
    val followingCount: Int = 28,
    val likesCount: Int = 140,
    val reportsCount: Int = 0,
    val totalViews: Int = 100,
    val videosCount: Int = 22,
    val accountAgeDays: Int = 14,
    val strikesCount: Int = 0,
    val banned: Boolean = false,
    val bannedByReports: Boolean = false,
    val coins: Int = 1500,
    val diamonds: Int = 6500,
    val withdrawnNaira: Int = 0,
    val isBusiness: Boolean = false,
    val dataSaver: Boolean = false,
    val relation: String = "contact" // contact | friend | discover | self
)

data class VideoComment(
    val id: String,
    val userId: String,
    val username: String,
    val text: String,
    val createdAt: String,
    val verified: Boolean = false
)

data class VideoPost(
    val id: String,
    val authorId: String,
    val authorName: String,
    val authorHandle: String,
    val authorVerified: Boolean,
    val category: String, // contacts | friends | foryou
    val caption: String,
    val musicTrack: String,
    val themeColorHex: Long = 0xFF1E3A8A,
    val likes: Int,
    val likedByMe: Boolean = false,
    val favourites: Int,
    val favouritedByMe: Boolean = false,
    val shares: Int,
    val views: Int,
    val reportsCount: Int = 0,
    val comments: List<VideoComment> = emptyList(),
    val createdAt: String = "2h ago",
    val isSponsoredAd: Boolean = false,
    val sponsorBrand: String? = null,
    val sponsorCta: String? = null
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val type: MessageType = MessageType.TEXT,
    val text: String,
    val voiceDuration: String? = null,
    val timestamp: String
)

data class ChatThread(
    val id: String,
    val participantId: String,
    val participantName: String,
    val participantPhone: String,
    val participantVerified: Boolean,
    val isGroup: Boolean = false,
    val groupMembersCount: Int = 0,
    val unreadCount: Int = 0,
    val lastMessage: String,
    val lastTimestamp: String,
    val messages: List<ChatMessage>
)

data class StatusUpdate(
    val id: String,
    val userId: String,
    val userName: String,
    val userVerified: Boolean,
    val caption: String,
    val createdAt: String,
    val expiresInHours: Int = 24,
    val viewed: Boolean = false
)

data class BelonaInboxItem(
    val id: String,
    val type: String, // like | comment | follow | gift | safety | verification
    val title: String,
    val detail: String,
    val timestamp: String,
    val read: Boolean = false
)

data class GiftItem(
    val id: String,
    val emoji: String,
    val name: String,
    val coins: Int,
    val naira: Int
)

data class BannedUserRecord(
    val id: String,
    val userId: String,
    val phone: String,
    val username: String,
    val reason: String,
    val banType: String,
    val strikesCount: Int,
    val reportRatioPercent: Double
)

object InitialBelonaData {
    val FORBIDDEN_TERMS = listOf(
        "SEXUAL", "NUDITY", "PORN", "KILLING", "GUNSHOT", "GUNS",
        "BLOOD", "DRUGS", "SUICIDE", "NAKED", "NSFW", "XXX", "MURDER"
    )

    val GIFT_CATALOG = listOf(
        GiftItem("gift-box", "🎁", "Box", 100, 100),
        GiftItem("gift-rose", "🌹", "Rose", 500, 500),
        GiftItem("gift-lion", "🦁", "Lion", 5000, 5000),
        GiftItem("gift-moneybag", "💰", "Money Bag", 10000, 10000),
        GiftItem("gift-mansion", "🏯", "Mansion", 50000, 50000)
    )

    val INITIAL_USERS = listOf(
        UserProfile(
            id = "usr-tunde",
            username = "Tunde Bakare",
            handle = "@tunde_vibes",
            phone = "+2348023456789",
            dob = "1999-05-14",
            bio = "Lagos rooftop choreographer & Afrobeats movement director.",
            verifiedStatus = true,
            followersCount = 142000,
            followingCount = 310,
            likesCount = 890400,
            reportsCount = 1,
            totalViews = 450000,
            videosCount = 48,
            accountAgeDays = 240,
            coins = 4500,
            diamonds = 18500,
            relation = "contact"
        ),
        UserProfile(
            id = "usr-amina",
            username = "Amina Bello",
            handle = "@amina_tech",
            phone = "+2348034567890",
            dob = "2001-11-08",
            bio = "Abuja systems architect & mobile hardware reviewer.",
            verifiedStatus = false,
            verificationPending = true,
            followersCount = 68400,
            followingCount = 195,
            likesCount = 320100,
            reportsCount = 1,
            totalViews = 180000,
            videosCount = 34,
            accountAgeDays = 120,
            coins = 2000,
            diamonds = 6200,
            isBusiness = true,
            relation = "friend"
        ),
        UserProfile(
            id = "usr-chidi",
            username = "Chidi Okafor",
            handle = "@chidi_couture",
            phone = "+2348056789012",
            dob = "1997-03-22",
            bio = "West African tailored streetwear. Victoria Island flagship.",
            verifiedStatus = true,
            followersCount = 94500,
            followingCount = 412,
            likesCount = 512000,
            reportsCount = 0,
            totalViews = 290000,
            videosCount = 62,
            accountAgeDays = 310,
            coins = 15000,
            diamonds = 42000,
            isBusiness = true,
            relation = "contact"
        ),
        UserProfile(
            id = "usr-kemi",
            username = "Kemi Adeyemi",
            handle = "@kemi_daily",
            phone = "+2348091112233",
            dob = "2003-07-19",
            bio = "Visual diary, food spots & weekend runs in Lekki.",
            verifiedStatus = false,
            followersCount = 1420,
            followingCount = 520,
            likesCount = 12800,
            reportsCount = 8,
            totalViews = 100,
            videosCount = 12,
            accountAgeDays = 45,
            strikesCount = 1,
            coins = 300,
            diamonds = 0,
            relation = "discover"
        )
    )

    val INITIAL_CHATS = listOf(
        ChatThread(
            id = "chat-1",
            participantId = "usr-tunde",
            participantName = "Tunde Bakare",
            participantPhone = "+2348023456789",
            participantVerified = true,
            unreadCount = 2,
            lastMessage = "Are you joining the Belona Live stream at 8 PM?",
            lastTimestamp = "10:42 AM",
            messages = listOf(
                ChatMessage(
                    id = "m-1",
                    senderId = "usr-tunde",
                    senderName = "Tunde Bakare",
                    type = MessageType.TEXT,
                    text = "Bro! Just uploaded the new rooftop rehearsal clip on Belona feed.",
                    timestamp = "10:40 AM"
                ),
                ChatMessage(
                    id = "m-2",
                    senderId = "usr-tunde",
                    senderName = "Tunde Bakare",
                    type = MessageType.TEXT,
                    text = "Are you joining the Belona Live stream at 8 PM?",
                    timestamp = "10:42 AM"
                )
            )
        ),
        ChatThread(
            id = "chat-2",
            participantId = "usr-chidi",
            participantName = "Chidi Okafor",
            participantPhone = "+2348056789012",
            participantVerified = true,
            unreadCount = 0,
            lastMessage = "Sent the lookbook photo for your fitting.",
            lastTimestamp = "09:15 AM",
            messages = listOf(
                ChatMessage(
                    id = "m-3",
                    senderId = "usr-chidi",
                    senderName = "Chidi Okafor",
                    type = MessageType.IMAGE,
                    text = "Sent the lookbook photo for your fitting.",
                    timestamp = "09:15 AM"
                )
            )
        ),
        ChatThread(
            id = "chat-3",
            participantId = "usr-amina",
            participantName = "Amina Bello",
            participantPhone = "+2348034567890",
            participantVerified = false,
            unreadCount = 1,
            lastMessage = "Just applied for my Blue Tick verification!",
            lastTimestamp = "Yesterday",
            messages = listOf(
                ChatMessage(
                    id = "m-4",
                    senderId = "usr-amina",
                    senderName = "Amina Bello",
                    type = MessageType.TEXT,
                    text = "Just applied for my Blue Tick verification!",
                    timestamp = "Yesterday"
                )
            )
        ),
        ChatThread(
            id = "chat-4",
            participantId = "group-creators",
            participantName = "Lagos Creators Hub",
            participantPhone = "+2348000001111",
            participantVerified = true,
            isGroup = true,
            groupMembersCount = 18,
            unreadCount = 0,
            lastMessage = "Voice note (0:24) — Community safety rules reminder",
            lastTimestamp = "Yesterday",
            messages = listOf(
                ChatMessage(
                    id = "m-5",
                    senderId = "usr-tunde",
                    senderName = "Tunde Bakare",
                    type = MessageType.VOICE,
                    text = "Community safety rules reminder: zero tolerance for prohibited videos.",
                    voiceDuration = "0:24",
                    timestamp = "Yesterday"
                )
            )
        )
    )

    val INITIAL_STATUSES = listOf(
        StatusUpdate(
            id = "st-1",
            userId = "usr-tunde",
            userName = "Tunde Bakare",
            userVerified = true,
            caption = "Going LIVE in 10 minutes! Tap Belona center tab to join the dance cipher 🔥",
            createdAt = "35m ago",
            expiresInHours = 23,
            viewed = false
        ),
        StatusUpdate(
            id = "st-2",
            userId = "usr-chidi",
            userName = "Chidi Okafor",
            userVerified = true,
            caption = "Studio doors open until 7 PM in Victoria Island. Custom measurements available.",
            createdAt = "3h ago",
            expiresInHours = 21,
            viewed = false
        ),
        StatusUpdate(
            id = "st-3",
            userId = "usr-amina",
            userName = "Amina Bello",
            userVerified = false,
            caption = "Tip: Enable Belona Data Saver in settings to cut mobile data usage by 60% on MTN/Airtel.",
            createdAt = "6h ago",
            expiresInHours = 18,
            viewed = true
        )
    )

    val INITIAL_VIDEOS = listOf(
        VideoPost(
            id = "vid-1",
            authorId = "usr-tunde",
            authorName = "Tunde Bakare",
            authorHandle = "@tunde_vibes",
            authorVerified = true,
            category = "foryou",
            caption = "Golden hour rooftop rehearsal in Marina before the Friday live showcase. #LagosDance #Afrobeats",
            musicTrack = "Original Sound — Tunde Bakare Live Percussion",
            themeColorHex = 0xFF1E3A8A,
            likes = 18420,
            favourites = 3410,
            shares = 912,
            views = 64200,
            comments = listOf(
                VideoComment("c-1", "usr-chidi", "Chidi Okafor", "That footwork transition on the beat drop is unmatched!", "12m ago", true),
                VideoComment("c-2", "usr-amina", "Amina Bello", "Going live tonight? Ready with the Lion gifts!", "5m ago", false)
            ),
            createdAt = "2h ago"
        ),
        VideoPost(
            id = "vid-2",
            authorId = "usr-amina",
            authorName = "Amina Bello",
            authorHandle = "@amina_tech",
            authorVerified = false,
            category = "friends",
            caption = "How we optimized low-bandwidth video streaming for West African mobile networks with Data Saver.",
            musicTrack = "Abuja Synth Session — LoFi Ambient",
            themeColorHex = 0xFF0F172A,
            likes = 9310,
            likedByMe = true,
            favourites = 2190,
            favouritedByMe = true,
            shares = 480,
            views = 31000,
            comments = listOf(
                VideoComment("c-3", "usr-tunde", "Tunde Bakare", "Super helpful breakdown. Data Saver works smoothly.", "1h ago", true)
            ),
            createdAt = "4h ago"
        ),
        VideoPost(
            id = "vid-3",
            authorId = "usr-chidi",
            authorName = "Chidi Okafor",
            authorHandle = "@chidi_couture",
            authorVerified = true,
            category = "contacts",
            caption = "New hand-dyed Aso-Oke structured jackets dropping this weekend at our Victoria Island studio.",
            musicTrack = "Runway Lagos — Instrumental",
            themeColorHex = 0xFF064E3B,
            likes = 24150,
            favourites = 5120,
            shares = 1340,
            views = 88500,
            createdAt = "6h ago"
        ),
        VideoPost(
            id = "vid-4",
            authorId = "usr-kemi",
            authorName = "Kemi Adeyemi",
            authorHandle = "@kemi_daily",
            authorVerified = false,
            category = "foryou",
            caption = "Late afternoon breeze across Lekki-Ikoyi link bridge. Rate the sunset 1-10!",
            musicTrack = "Coastal Drive — Acoustic Guitar",
            themeColorHex = 0xFF311042,
            likes = 640,
            favourites = 95,
            shares = 28,
            views = 100,
            reportsCount = 8,
            createdAt = "8h ago"
        ),
        VideoPost(
            id = "vid-sponsored-ad-1",
            authorId = "sponsor-mtn-fiber",
            authorName = "MTN 5G Ultra & Enterprise",
            authorHandle = "@mtn_nigeria_official",
            authorVerified = true,
            category = "foryou",
            caption = "Experience ultra-low latency 5G home & studio connectivity across Nigeria. Note: Mobile data is billed by your carrier, never by Belona.",
            musicTrack = "Sponsored Commercial Audio — MTN 5G",
            themeColorHex = 0xFF422006,
            likes = 45200,
            favourites = 6100,
            shares = 3200,
            views = 520000,
            createdAt = "Sponsored",
            isSponsoredAd = true,
            sponsorBrand = "MTN 5G Ultra Fiber",
            sponsorCta = "Explore Data Plans"
        )
    )

    val INITIAL_INBOX = listOf(
        BelonaInboxItem(
            id = "inb-1",
            type = "safety",
            title = "AMA AI Auto-Moderation Active",
            detail = "Belona AI Safety Shield is protecting your feed from prohibited content 24/7.",
            timestamp = "Just now"
        ),
        BelonaInboxItem(
            id = "inb-2",
            type = "like",
            title = "Tunde Bakare liked your video",
            detail = "Your vertical clip received 120 new likes in the last hour.",
            timestamp = "18m ago"
        ),
        BelonaInboxItem(
            id = "inb-3",
            type = "gift",
            title = "Live Gift 50/50 Split Ready",
            detail = "Host receives 50% in Diamonds automatically when you stream live (5+ followers required).",
            timestamp = "2h ago",
            read = true
        )
    )

    val INITIAL_BANNED_RECORDS = listOf(
        BannedUserRecord(
            id = "ban-101",
            userId = "usr-banned-demo",
            phone = "+2348099990000",
            username = "@toxic_poster_99",
            reason = "Auto-Ban: Reached 5/5 strikes for prohibited violent/explicit content",
            banType = "STRIKES_5",
            strikesCount = 5,
            reportRatioPercent = 18.4
        ),
        BannedUserRecord(
            id = "ban-102",
            userId = "usr-scammer-demo",
            phone = "+2348122223333",
            username = "@crypto_doubler_ng",
            reason = "Community Report 30% Rule: 34.2% of viewers reported account",
            banType = "COMMUNITY_REPORTS_30_PERCENT",
            strikesCount = 2,
            reportRatioPercent = 34.2
        )
    )
}
