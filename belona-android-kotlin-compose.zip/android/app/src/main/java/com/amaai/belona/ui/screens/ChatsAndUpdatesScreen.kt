package com.amaai.belona.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amaai.belona.model.*
import com.amaai.belona.ui.theme.BelonaDeepNavy
import com.amaai.belona.ui.theme.BelonaEmerald
import com.amaai.belona.ui.theme.BelonaRoyalBlue
import com.amaai.belona.ui.theme.BelonaSkyBlue
import com.amaai.belona.ui.theme.BelonaSlate800
import com.amaai.belona.ui.theme.BelonaSlate900

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsAndUpdatesScreen(
    activeSurface: BelonaSurface,
    currentUser: UserProfile,
    chats: List<ChatThread>,
    statuses: List<StatusUpdate>,
    onChangeSurface: (BelonaSurface) -> Unit,
    onSendMessage: (chatId: String, text: String, type: MessageType, voiceDuration: String?) -> Unit,
    onCreateChatOrGroup: (name: String, phone: String, isGroup: Boolean) -> Unit,
    onAddStatus: (caption: String) -> Unit,
    onMarkStatusViewed: (statusId: String) -> Unit,
    onToggleDataSaver: () -> Unit
) {
    var selectedChatId by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var showNewStatusDialog by remember { mutableStateOf(false) }
    var activeStatusViewer by remember { mutableStateOf<StatusUpdate?>(null) }

    val activeChat = chats.find { it.id == selectedChatId }

    // Active Full-Screen Conversation View (like WhatsApp / Telegram)
    if (activeChat != null) {
        ChatConversationScreen(
            chat = activeChat,
            currentUserId = currentUser.id,
            onBack = { selectedChatId = null },
            onSendMessage = { text, type, duration ->
                onSendMessage(activeChat.id, text, type, duration)
            }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BelonaSlate900,
                    titleContentColor = Color.White
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BelonaLogoBadge(size = 34.dp, fontSizeSp = 18)
                        Column {
                            Text(
                                text = "BELONA",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            Text(
                                text = if (currentUser.dataSaver) "Data Saver ON · Standalone App" else "Standalone Android Messenger",
                                fontSize = 10.sp,
                                color = BelonaSkyBlue
                            )
                        }
                    }
                },
                actions = {
                    TextButton(onClick = onToggleDataSaver) {
                        Text(
                            text = if (currentUser.dataSaver) "Data Saver: ON" else "Data Saver",
                            color = if (currentUser.dataSaver) BelonaEmerald else Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = { onChangeSurface(BelonaSurface.ADMIN) }) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Admin Dashboard",
                            tint = BelonaSkyBlue
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (activeSurface == BelonaSurface.UPDATES) {
                        showNewStatusDialog = true
                    } else {
                        showNewChatDialog = true
                    }
                },
                containerColor = BelonaRoyalBlue,
                contentColor = Color.White
            ) {
                Icon(
                    imageVector = if (activeSurface == BelonaSurface.UPDATES) Icons.Default.AddAPhoto else Icons.Default.AddComment,
                    contentDescription = "New Chat or Status"
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = BelonaSlate900,
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = activeSurface == BelonaSurface.CHATS,
                    onClick = { onChangeSurface(BelonaSurface.CHATS) },
                    icon = { Icon(Icons.Default.ChatBubble, contentDescription = "Chats") },
                    label = { Text("Chats", fontWeight = FontWeight.Bold) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { onChangeSurface(BelonaSurface.BELONA) },
                    icon = {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(BelonaRoyalBlue)
                                .border(2.dp, BelonaSkyBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Belona Videos",
                                tint = Color.White
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "Belona",
                            color = BelonaSkyBlue,
                            fontWeight = FontWeight.Black
                        )
                    }
                )
                NavigationBarItem(
                    selected = activeSurface == BelonaSurface.UPDATES,
                    onClick = { onChangeSurface(BelonaSurface.UPDATES) },
                    icon = { Icon(Icons.Default.AutoAwesomeMotion, contentDescription = "24h Updates") },
                    label = { Text("Updates (24h)", fontWeight = FontWeight.Bold) }
                )
            }
        },
        containerColor = BelonaDeepNavy
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search chats, +234 contacts, or groups...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp)
            )

            if (activeSurface == BelonaSurface.CHATS) {
                val filteredChats = chats.filter {
                    it.participantName.contains(searchQuery, ignoreCase = true) ||
                        it.lastMessage.contains(searchQuery, ignoreCase = true)
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(filteredChats, key = { it.id }) { thread ->
                        ChatRowItem(
                            thread = thread,
                            onClick = { selectedChatId = thread.id }
                        )
                        HorizontalDivider(color = BelonaSlate800.copy(alpha = 0.5f))
                    }
                }
            } else {
                // 24-Hour Status Updates Surface
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showNewStatusDialog = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                BelonaLogoBadge(size = 48.dp, fontSizeSp = 22)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "My Status (24-Hour Disappearing)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = "Tap to post a 24h photo or text update",
                                        color = BelonaSkyBlue,
                                        fontSize = 12.sp
                                    )
                                }
                                Icon(Icons.Default.AddCircle, contentDescription = null, tint = BelonaSkyBlue)
                            }
                        }
                    }

                    items(statuses, key = { it.id }) { status ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BelonaSlate900),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onMarkStatusViewed(status.id)
                                    activeStatusViewer = status
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(BelonaRoyalBlue)
                                        .border(
                                            width = 2.5.dp,
                                            color = if (status.viewed) Color.Gray else BelonaEmerald,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = status.userName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = status.userName,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        if (status.userVerified) {
                                            VerifiedBlueTick()
                                        }
                                    }
                                    Text(
                                        text = status.caption,
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${status.createdAt} · Expires in ${status.expiresInHours}h",
                                        color = BelonaSkyBlue,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewChatDialog) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("+23480") }
        var isGroup by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            title = { Text("New BELONA Chat / Group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Contact or Group Name") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone (+234)") },
                        singleLine = true
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isGroup, onCheckedChange = { isGroup = it })
                        Text("Create as Group Chat")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateChatOrGroup(name, phone, isGroup)
                        showNewChatDialog = false
                    }
                ) {
                    Text("Start Chat")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewChatDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showNewStatusDialog) {
        var caption by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewStatusDialog = false },
            title = { Text("Post 24-Hour Status Update") },
            text = {
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("What's happening today?") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddStatus(caption)
                        showNewStatusDialog = false
                    }
                ) {
                    Text("Post 24h Status")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewStatusDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (activeStatusViewer != null) {
        val st = activeStatusViewer!!
        AlertDialog(
            onDismissRequest = { activeStatusViewer = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(st.userName, fontWeight = FontWeight.Bold)
                    if (st.userVerified) VerifiedBlueTick()
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(st.caption, fontSize = 16.sp, color = Color.White)
                    Text(
                        "Posted ${st.createdAt} · Auto-deletes after ${st.expiresInHours}h",
                        fontSize = 11.sp,
                        color = BelonaSkyBlue
                    )
                }
            },
            confirmButton = {
                Button(onClick = { activeStatusViewer = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun ChatRowItem(thread: ChatThread, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(BelonaRoyalBlue),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = thread.participantName.take(1).uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 20.sp
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = thread.participantName,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                if (thread.participantVerified) {
                    VerifiedBlueTick()
                }
                if (thread.isGroup) {
                    Text(
                        text = "(${thread.groupMembersCount})",
                        color = BelonaSkyBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = thread.lastMessage,
                color = Color.LightGray,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = thread.lastTimestamp,
                color = if (thread.unreadCount > 0) BelonaSkyBlue else Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (thread.unreadCount > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(BelonaRoyalBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = thread.unreadCount.toString(),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatConversationScreen(
    chat: ChatThread,
    currentUserId: String,
    onBack: () -> Unit,
    onSendMessage: (text: String, type: MessageType, voiceDuration: String?) -> Unit
) {
    var messageText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BelonaSlate900),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = chat.participantName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            if (chat.participantVerified) {
                                VerifiedBlueTick()
                            }
                        }
                        Text(
                            text = chat.participantPhone,
                            color = BelonaSkyBlue,
                            fontSize = 11.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            onSendMessage("Shared a photo from gallery", MessageType.IMAGE, null)
                        }
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = "Send Photo", tint = BelonaSkyBlue)
                    }
                    IconButton(
                        onClick = {
                            onSendMessage("Voice note", MessageType.VOICE, "0:15")
                        }
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Send Voice Note", tint = BelonaEmerald)
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = BelonaSlate900) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("Message on BELONA...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )
                    FloatingActionButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                onSendMessage(messageText.trim(), MessageType.TEXT, null)
                                messageText = ""
                            }
                        },
                        containerColor = BelonaRoyalBlue,
                        contentColor = Color.White,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        },
        containerColor = BelonaDeepNavy
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            items(chat.messages, key = { it.id }) { msg ->
                val isMe = msg.senderId == currentUserId
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Surface(
                        color = if (isMe) BelonaRoyalBlue else BelonaSlate800,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.widthIn(max = 290.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (!isMe && chat.isGroup) {
                                Text(
                                    text = msg.senderName,
                                    color = BelonaSkyBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            val displayBody = when (msg.type) {
                                MessageType.VOICE -> "🎤 Voice Note (${msg.voiceDuration ?: "0:15"}): ${msg.text}"
                                MessageType.IMAGE -> "📷 Photo: ${msg.text}"
                                MessageType.VIDEO -> "🎬 Video: ${msg.text}"
                                MessageType.TEXT -> msg.text
                            }
                            Text(
                                text = displayBody,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = msg.timestamp,
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.End)
                            )
                        }
                    }
                }
            }
        }
    }
}
